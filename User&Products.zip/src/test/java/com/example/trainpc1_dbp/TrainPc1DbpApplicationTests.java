package com.example.trainpc1_dbp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainPc1DbpApplicationTests {

	@Test
	void contextLoads() {
	}

}
