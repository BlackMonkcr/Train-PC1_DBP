package com.example.trainpc1_dbp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainPc1DbpApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainPc1DbpApplication.class, args);
	}

}
